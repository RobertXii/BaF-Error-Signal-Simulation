"""This files contains the spins quantum numbers for the molecule""" 
S = 1/2
I1=0
I2=1/2
LAMBDA = 1
SIGMA = -1/2
OMEGA = 1/2

